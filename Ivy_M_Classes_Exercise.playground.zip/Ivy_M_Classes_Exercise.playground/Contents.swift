import UIKit

class dodgeChallenger {
    var engine: String = "v8"
    var color: String = "Red"
    var upholstery: Bool = true
    
    func carDefined (){
        print("I love my car!")
    }
}
var car = dodgeChallenger()
